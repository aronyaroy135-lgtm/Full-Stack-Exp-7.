package com.shibaji.jwtauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
