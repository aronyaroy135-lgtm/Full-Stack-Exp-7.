package com.shibaji.jwtauth.dto;

public record AuthResponse(
        String token,
        String tokenType,
        String email,
        String role
) {
}