package com.shibaji.jwtauth.entity;

public enum Role {
    USER,
    ADMIN
}