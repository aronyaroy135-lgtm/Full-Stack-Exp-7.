package com.shibaji.jwtauth.controller;

import com.shibaji.jwtauth.entity.AppUser;
import com.shibaji.jwtauth.repository.UserRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/api/user/profile")
    public ResponseEntity<?> getProfile(Authentication authentication) {

        return userRepository.findByEmail(authentication.getName())
            .<ResponseEntity<?>>map(user ->
                ResponseEntity.ok(
                    Map.of(
                        "id", user.getId(),
                        "name", user.getName(),
                        "email", user.getEmail(),
                        "role", user.getRole().name()
                    )
                )
            )
            .orElseGet(() ->
                ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "User not found"))
            );
    }

    @GetMapping("/api/admin/dashboard")
    public ResponseEntity<?> adminDashboard() {

        return ResponseEntity.ok(
            Map.of(
                "message", "Welcome to the administrator dashboard",
                "access", "ADMIN",
                "status", "Authorized"
            )
        );
    }
}