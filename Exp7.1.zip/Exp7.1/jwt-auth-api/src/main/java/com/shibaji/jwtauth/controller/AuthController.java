package com.shibaji.jwtauth.controller;

import com.shibaji.jwtauth.dto.AuthResponse;
import com.shibaji.jwtauth.dto.LoginRequest;
import com.shibaji.jwtauth.dto.RegisterRequest;

import com.shibaji.jwtauth.entity.AppUser;
import com.shibaji.jwtauth.entity.Role;

import com.shibaji.jwtauth.repository.UserRepository;
import com.shibaji.jwtauth.security.JwtService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthController(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            AuthenticationManager authenticationManager,
            JwtService jwtService) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(
            @Valid @RequestBody RegisterRequest request) {

        String email = request.email().trim().toLowerCase();

        if (userRepository.existsByEmail(email)) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body("An account with this email already exists");
        }

        AppUser user = new AppUser(
            request.name().trim(),
            email,
            passwordEncoder.encode(request.password()),
            Role.USER
        );

        userRepository.save(user);

        return ResponseEntity.status(HttpStatus.CREATED)
            .body("User registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(
            @Valid @RequestBody LoginRequest request) {

        String email = request.email().trim().toLowerCase();

        Authentication authentication =
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    email,
                    request.password()
                )
            );

        UserDetails userDetails =
            (UserDetails) authentication.getPrincipal();

        String token = jwtService.generateToken(userDetails);

        String role = userDetails.getAuthorities()
            .stream()
            .findFirst()
            .map(authority -> authority.getAuthority())
            .orElse("ROLE_USER");

        return ResponseEntity.ok(
            new AuthResponse(token, "Bearer", email, role)
        );
    }
}