package com.shibaji.jwtauth.config;

import com.shibaji.jwtauth.entity.AppUser;
import com.shibaji.jwtauth.entity.Role;
import com.shibaji.jwtauth.repository.UserRepository;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.boot.CommandLineRunner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initializeAdmin(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            @Value("${app.admin.email}") String adminEmail,
            @Value("${app.admin.password}") String adminPassword) {

        return args -> {

            String email = adminEmail.trim().toLowerCase();

            if (userRepository.existsByEmail(email)) {
                return;
            }

            AppUser admin = new AppUser(
                "System Administrator",
                email,
                passwordEncoder.encode(adminPassword),
                Role.ADMIN
            );

            userRepository.save(admin);

            System.out.println(
                "Development administrator initialized: " + email
            );
        };
    }
}